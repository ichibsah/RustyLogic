using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace RustyLogic.RedDotNet 
{
    public class Link : RedDotObject
    {
        // Structural elements i.e. LINKS
        private string _name;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        protected Link(XmlNode xmlNode) : base(xmlNode) { }
        protected Link(Guid guid) : base(guid) { }

        protected override void LoadBasics(XmlNode xmlNode)
        {
            _name = xmlNode.Attributes.GetNamedItem("name").Value;
        }

        protected override XmlNode LoadXml()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public static List<Link> List(Page page)
        {
            List<Link> links = new List<Link>();
            string rqlStatement =
                "<IODATA>" +
                    "<PAGE guid=\"" + page.GuidString + "\">" +
                        "<LINKS action=\"load\"/>" +
                    "</PAGE>" +
                "</IODATA>";

            xmlDoc.LoadXml(Session.Execute(rqlStatement));
            XmlNodeList xmlNodes = xmlDoc.GetElementsByTagName("LINK");
            foreach (XmlNode xmlNode in xmlNodes)
            {
                links.Add(new Link(xmlNode));
            }
            return links;
        }

        public PublicationPackage PublicationPackage
        {
            get
            {
                return PublicationPackage.Get(this);
            }
            set
            {
                value.Assign(this, false);
            }
        }

        public Workflow Workflow
        {
            get
            {
                throw new Exception("Not implemented.");
            }
            set
            {
                value.Assign(this);
            }
        }

        public void CreateAndConnect(Template template, string headline)
        {
            XmlDocument rqlXml = new XmlDocument();
            XmlElement ioDataElement = rqlXml.CreateElement("IODATA");
            XmlElement linkElement = rqlXml.CreateElement("LINK");
            linkElement.SetAttribute("action", "assign");
            linkElement.SetAttribute("guid", GuidString);

            XmlElement pageElement = rqlXml.CreateElement("PAGE");
            pageElement.SetAttribute("action", "addnew");
            pageElement.SetAttribute("templateguid", template.GuidString);
            pageElement.SetAttribute("headline", headline);

            linkElement.AppendChild(pageElement);
            ioDataElement.AppendChild(linkElement);
            rqlXml.AppendChild(ioDataElement);

            Session.Execute(rqlXml, Session.Info.SessionKey);

        }
    }
}
