using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace RustyLogic.RedDotNet.Elements
{
    public class TextHtml : Element
    {
        private bool _filled;

        public bool Filled
        {
            get { return _filled; }
            set { _filled = value; }
        }

        internal TextHtml(XmlNode xmlNode) : base(xmlNode) { }
        internal TextHtml(Guid guid) : base(guid) { }

        protected override void LoadBasics(XmlNode xmlNode)
        {
            base.LoadBasics(xmlNode);
            //_filled = int.Parse(xmlNode.Attributes.GetNamedItem("name").Value) == 1;
        }

        override public string Value
        {
            get
            {
                if (!Filled || base.Value == null)
                {
                    string rqlStatement = 
                        "<IODATA format=\"" + (int)Element.Format.Text + "\">" +
                            "<ELT action=\"load\" guid=\"" + GuidString + "\"/>" +
                        "</IODATA>";
                    base.Value = Session.Execute(rqlStatement);
                }
                return base.Value;
            }
            set
            {
                string rqlStatement =
                        "<IODATA format=\"" + (int)Element.Format.Text + "\">" +
                            "<ELT action=\"save\" guid=\"" + GuidString + "\">" +
                                EscapeXmlForRedDot(value) + 
                            "</ELT>" +
                        "</IODATA>";
                Session.Execute(rqlStatement);
                base.Value = value;
            }
        }
    }
}
